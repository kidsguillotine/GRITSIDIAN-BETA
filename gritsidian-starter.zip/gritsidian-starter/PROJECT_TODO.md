---
title: Project To-Do: Claudian Starter
created: 2026-08-18
meta_status: active
purpose: >
  Single running to-do list for the Claudian Starter. This is a personal project
  and a tool, not a product. Keep it plain. Add items at the bottom of a section;
  check them off in place.
update_trigger: Add a line when new work appears; check it off when done.
---

# Project To-Do: Claudian Starter

Framing: this is a **project and a tool**, not a product. No roadmap, no
release, no marketing. It exists so one person (and a few testers) can run an
Obsidian vault with an AI helper and not lose data. Every item below serves that.

## Done (this build)

- [x] Genericized `CLAUDE.md` (rules, no personal content)
- [x] Curated `.claudian/scripts/` (43 reusable scripts, scrubbed)
- [x] All 5 skills ported and scrubbed
- [x] Empty vault taxonomy with per-folder README
- [x] `_handoff/` and `99_system/` doc templates
- [x] `.claude/settings.json` hook wiring (rm-guard + handoff regen)
- [x] Git `pre-commit` guard + `install.sh`
- [x] `setup.sh` + `SETUP.md` (placeholder replacement)
- [x] PII scrub audit (0 leaks)

## Now: documentation (this request)

- [x] Consolidated to-do list (this file)
- [x] Wiki-style starter guide (`wiki/` folder, interlinked notes)
- [x] Rewrite root `README.md` as the wiki front door
- [x] Simplified rules in ASD-STE100 (Simplified Technical English): `wiki/The Rules (Simple English)`
- [x] Plain-language pages for non-technical readers + `wiki/Glossary`
- [x] Explain git integration and why backup matters: `wiki/Git Backup`
- [x] Explain the sensitivity split, the pre-commit trigger, and the security-fires protocol: `wiki/Sensitivity and Security`
- [x] Wikilinks reference page: `wiki/Wikilinks`
- [x] Required Obsidian + community plugins: `wiki/Plugins`
- [x] Port the formal structure/frontmatter spec: `99_system/DOC_STANDARD.md` (+ `wiki/Frontmatter and Structure`)
- [x] Windows + run-from-flash-drive prerequisites: `wiki/Windows and Flash Drive`

## Next: verify and harden

- [ ] Dry-run `setup.sh` on a copy in a throwaway path; confirm 0 placeholders remain
- [ ] Test git hooks fire: try to stage a `.md` delete and a bare `[[X.md]]` link; confirm block
- [ ] Confirm `check_links.py --count-broken` returns 0 on the empty vault
- [ ] Confirm `gen_session_boot.sh` runs after `setup.sh` and produces a valid SESSION_BOOT
- [ ] Windows path: verify scripts that assume POSIX paths degrade or document the WSL/Git-Bash requirement
- [ ] Decide: keep `crm/` in the starter, or drop it as optional

## Done (second pass)

- [x] RESOLVED via option B (user: "never emojis, never em dash over everything"): rewrote every parser delimiter to plain ASCII (OD header `### OD-N: Title`, MIGRATION_LOG `YYYY-MM-DD:`, GOTCHAS `### GN:`, SECURITY_FIRES status cell plain word `OPEN`). Global sweep removed all em-dashes, emojis, typographic arrows, and box-drawing across the whole export (scripts, skills, docs). Verified: 0 em-dashes, 0 emojis, parsers still return 0/0/0, all Python compiles, all shells pass `bash -n`.
- [x] Integrated the reusable `99_system` framework docs (TOKEN_DISCIPLINE, DESIGN_BY_LIMITATION, MODEL_ROUTING, AUTOMATION_ROUTING, FORMAT_CONTRACT_INVENTORY, CLAUDE_TOOL_MANIFEST, SUBAGENT_SPECS, SCRIPT_REGISTRY, SYSTEM_CONSTANTS, INTEGRITY_LAYER_SPEC, REBUILD_MOCS_SPEC, DOMAIN_HANDOFF_TEMPLATE, CAPTURE_QUICKREF); registered all in SYSTEM_DOC_MAP.
- [x] Grabbed from DOT_CLAUDE_COPY: `vault-classifier` subagent definition and `vo-system-prompt.md`.

## Open questions (need a decision)

- [ ] Collapse the older vault versions (the ones that previously lived in `plans`) into the single vault we work with now. Inventory every prior vault copy, pick the canonical one, migrate any unique content, and retire the rest. This is a prerequisite to a clean single source of truth.
- [ ] Ported `99_system` docs still carry historical references (OD numbers, dated incidents, script names not in the starter). Decide whether to do a content-trim pass or ship as archaeological reference.
- [ ] `SCRIPT_REGISTRY.md` and `SYSTEM_CONSTANTS.md` may list scripts/paths that are not in the curated starter set. Reconcile against the shipped `.claudian/scripts/`.
- [ ] Should `_export/` be added to the main vault `.gitignore` so it does not ride the hourly snapshot into the private vault repo?
- [ ] Windows support level: WSL2 required, or Git-Bash-only path documented? (affects prerequisites)
- [ ] Flash-drive target: which host OS(es) must the drive boot/run on?
- [ ] Does the starter ship the local-model stack docs, or stay cloud-only with a pointer?

## Parked (tracked elsewhere, NOT part of this shareable starter)

These live in the private vault `_handoff/`, not here. Listed by name only so the
thread is not lost. Do not copy their detail into this folder.

- Vault-wide: broken-wikilink repair, push-failure log, session open-decisions.
- Hardware: SanDisk SSD recovery (active fire).

Reason kept separate: this folder is meant to be handed to testers. Personal
vault operations must not leak into it (see `wiki/Sensitivity and Security`).
