# _MOCs

Maps of Content. Managed by rebuild_mocs.py; do not hand-edit.

See `99_system/FOLDER_SCHEMA.md` for the full taxonomy.
