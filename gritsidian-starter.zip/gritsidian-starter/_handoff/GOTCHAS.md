---
title: Gotchas
created: 2026-08-18
meta_status: active
purpose: Environment- and tooling-specific traps discovered during operation. Append-only.
update_trigger: Append a numbered entry (G01, G02, ...) when a new trap is found.
---

# Gotchas

(none yet: append G01, G02, ... as you discover environment quirks)
