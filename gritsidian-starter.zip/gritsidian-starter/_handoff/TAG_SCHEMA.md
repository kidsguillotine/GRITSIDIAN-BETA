---
title: Tag Schema
created: 2026-08-18
meta_status: active
purpose: Governed tag vocabulary. Classification and tagging must use tags defined here.
update_trigger: Add a tag only with a clear definition and an example. Never assign an undefined tag.
---

# Tag Schema

Tags map loosely to the folder taxonomy. Define your own vocabulary here before
enabling auto-tagging. Rule (from CLAUDE.md): never assign a tag you cannot
justify from explicit evidence in the file content or filename.

## Starter vocabulary

| Tag | Meaning |
|---|---|
| `#personal` | Personal-life content |
| `#career` | Career / work |
| `#technical` | Code, systems, learning |
| `#idea` | Unstructured idea or note |
| `#review` | Needs human review |
