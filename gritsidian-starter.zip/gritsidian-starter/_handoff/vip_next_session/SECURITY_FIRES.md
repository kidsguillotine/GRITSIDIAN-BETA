---
title: Security Fires
created: 2026-08-18
meta_status: active
purpose: >
  Open security incidents that must be read and handled before other work.
  SESSION_BOOT surfaces the count. If the count is above zero, the agent reads
  this file first.
update_trigger: Add a table row when a fire is found. Change OPEN to CLOSED when fixed.
---

# Security Fires

Count of open fires is surfaced at session start as `Security fires: N`. If N is
zero, do nothing here.

FORMAT CONTRACT: the boot script counts table rows whose status cell contains the
plain word `OPEN`. Keep the status cell as `OPEN` or `CLOSED`, nothing else. See
`99_system/DOC_STANDARD.md` section 4.

## Status table

| Fire | Status | Action |
|---|---|---|
| Fire 0: example (delete this row) | CLOSED | none |

## Details

For each OPEN fire, add a short block: what leaked, where, and the first action.

## How to add a fire

1. Add a row: `| Fire N: short title | OPEN | first action |`.
2. Write the detail block below.
3. When fixed, change `OPEN` to `CLOSED` and note the date.
