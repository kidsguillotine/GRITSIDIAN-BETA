---
title: System Doc Map
created: 2026-08-18
meta_status: active
purpose: >
  Registry of every doc in a scoped folder (_handoff/, 99_system/). Every new
  scoped-folder doc MUST be registered here before commit (see CLAUDE.md
  "System-doc creation rule").
update_trigger: Add a row when a scoped-folder doc is created; remove on archive.
---

# System Doc Map

| Doc | Purpose | Authority |
|---|---|---|
| `CLAUDE.md` | Operating constitution | 1 |
| `99_system/FOLDER_SCHEMA.md` | Canonical top-level folder layout | 3 |
| `99_system/DOC_STANDARD.md` | Format/structure + frontmatter spec | 3 |
| `99_system/SYSTEM_DOC_MAP.md` | This registry | 4 |
| `99_system/API_CATALOG.md` | Local API catalog for /api-lookup | 6 |
| `99_system/TOKEN_DISCIPLINE.md` | Deterministic-script-over-per-item standing rule | 3 |
| `99_system/DESIGN_BY_LIMITATION.md` | Design philosophy | 5 |
| `99_system/MODEL_ROUTING.md` | Which model handles which work | 4 |
| `99_system/AUTOMATION_ROUTING.md` | Substrate routing (agent vs script vs workflow) | 4 |
| `99_system/FORMAT_CONTRACT_INVENTORY.md` | Scripts-that-parse-docs inventory | 3 |
| `99_system/CLAUDE_TOOL_MANIFEST.md` | allowed-tools reference for skills | 4 |
| `99_system/SUBAGENT_SPECS.md` | Subagent definitions | 4 |
| `99_system/SCRIPT_REGISTRY.md` | Registry of pipeline scripts | 4 |
| `99_system/SYSTEM_CONSTANTS.md` | Shared literals (do not hardcode elsewhere) | 3 |
| `99_system/INTEGRITY_LAYER_SPEC.md` | validate_system.sh check spec | 4 |
| `99_system/REBUILD_MOCS_SPEC.md` | rebuild_mocs.py spec | 4 |
| `99_system/DOMAIN_HANDOFF_TEMPLATE.md` | Template for a domain handoff | 5 |
| `99_system/CAPTURE_QUICKREF.md` | Capture-pipeline quick reference | 5 |
| `_handoff/SESSION_BOOT.md` | Session-start digest (generated) | 2 |
| `_handoff/BOOT_DELTA.md` | Delta since prior boot (generated) | 2 |
| `_handoff/OPEN_DECISIONS.md` | Pending decisions (confirmation gate) | 2 |
| `_handoff/IMPORTED_HANDOFFS.md` | External-agent imports pending review | 2 |
| `_handoff/PENDING_WORK.md` | Active work queue | 3 |
| `_handoff/GOTCHAS.md` | Environment traps (append-only) | 3 |
| `_handoff/TAG_SCHEMA.md` | Governed tag vocabulary | 3 |
| `_handoff/MIGRATION_LOG.txt` | Audit trail of structural ops | 2 |
| `_handoff/vip_next_session/README.md` | Transient next-session priority bucket | 2 |
| `_handoff/vip_next_session/SECURITY_FIRES.md` | Open security incidents | 2 |

Authority rank: lower number = higher authority. 1 = constitution, 2 = live
operational state, 3 = canonical reference, 4+ = registries and generated docs.
