---
title: Script Registry
created: 2026-06-11
meta_status: active
purpose: Standing registry of all pipeline scripts: versions, roles, layers. Renamed from SCRIPT_CONSOLIDATION_REVIEW.md 2026-06-14.
update_trigger: New script added, renamed, or removed from your-scripts/scripts/
tags: [system, scripts]
---

# Script Registry

Standing registry. Update when a script is added, renamed, or removed. See Consolidation candidates section for open review tasks.

---

## your-scripts/scripts/: Canonical distributable scripts

| Script | Version | Role | Layer | Notes |
|---|---|---|---|---|
| `vault_agent.py` | 2.6.1 | LLM agent loop: takes NL task, runs Ollama tool-use iteration, dispatches to primitives | Orchestration | Model-agnostic since v2.1.0; canonical path `your-scripts/scripts/vault_agent.py` |
| `agent_runner.py` | 1.5.0 | HTTP server: n8n -> vault_agent.py bridge. Single-threaded, write gates (lock file + temporal window) | Transport | Intentionally separate from vault_agent: do not merge |
| `link_safe_move.py` | 1.0.0 | Deterministic wikilink-safe move primitive: guards -> scan inbound wikilinks -> rewrite -> move -> log -> ChromaDB sync | Primitive | Core safety primitive; imported by vault_agent, must stay standalone |
| `classify.py` | 2.2.0 | Two-pass classifier: (1) quarantine check, (2) content tagging via Ollama. Writes #area/ tags to frontmatter | Pipeline | Vocab loaded from `.claudian/config/vocab.yaml` (D5 taxonomy) |
| `dedup_pipeline.py` |: | Hash dedup (BLAKE3 via czkawka_cli) + empty file/folder cleanup | Pipeline | merge_files.py NOT run here: different dedup mechanism |
| `merge_files.py` |: | Conservative semantic dedup for .md/.txt: 0.99 threshold, dry-run default, chunk-only | Pipeline | **Not in nightly pipeline**: chunk/intake use only |
| `chroma_reconcile.py` | 1.0.0 | ChromaDB sync: semantic (Ollama embed) or placeholder mode | Pipeline | Nightly via agent_runner /run-reconcile |
| `op_log.py` | 1.0.0 | Shared OPERATION_LOG.jsonl append utility: per-run audit trail | Utility | Used by: classify.py, vault_agent, validate_frontmatter |
| `op_idempotency.py` | 1.0.0 | Idempotency key store: prevents double-processing on pipeline retry | Utility | Used by: vault_agent |
| `validate_frontmatter.py` | 1.0.0 | Post-write frontmatter schema validator: observe+log only, never blocks | Utility | Post-write hook in vault_agent tool_write_note |
| `interaction_log.py` | 1.0.0 | Per-exchange audit log (INTERACTION_LOG.jsonl): per-message, not per-run | Utility | Sibling to op_log; different scope (exchange vs run) |
| `time_context.py` | 1.0.0 | Canonical time/date utilities for the stack: stdlib only, no deps | Utility | Single source of truth for timestamps across all scripts |
| `agent_memory.py` | 1.1.0 | Structured decision/fact/gotcha store. stdlib SQLite+FTS5, content-hashed IDs, supersedes field, conflict detection. DB+JSONL default to `~/.local/share/agent_memory/` (XDG, outside vault tree). | Primitive | Promoted to canonical 2026-06-21 (OD-7). Symlinked at `.claudian/scripts/agent_memory.py`. 22/22 behavior tests pass. Patched 2026-06-22: F3 busy_timeout, F4 dangling-supersedes detection, F6 microsecond timestamp (OD-26). |
| `test_qwen3_structured.py` |: | Gate test + transcript library builder. Single-pass: archives JSONL records to `.claudian/transcript_library/<type>/<session>/<line>.json`, samples user/assistant for structured-output compliance test. Read-only against vault. | Test harness | Relocated from vault root 2026-06-21. Not yet run. Threshold tiers: TOP ≥0.95, MID 0.80-0.95, FLOOR <0.80. Verify `.claudian/` gitignore before running (privacy gate on transcript archival). |
| `reconcile_session.py` |: | L-1 reconcile loop (OD-16 / IH-3). At session close, diffs live JSONL transcript against agent_memory.py captures. Surfaces decision/fact/gotcha snippets that were missed by auto-extraction. | Session tool | Built 2026-06-22. Wired into session_close.sh as Step 2b. Symlinked at `.claudian/scripts/reconcile_session.py`. |
| `inference.py` | 1.0.0 | Swappable inference backend: Ollama or Claude API. Abstracts model selection from calling scripts. | Utility | Built 2026-06-24. Canonical at `your-scripts/scripts/inference.py`. |
| `chunk_store.py` | 1.0.0 | Chunk, hash, and persist document content to SQLite. Foundation for semantic dedup and retrieval. | Primitive | Built 2026-06-24. Canonical at `your-scripts/scripts/chunk_store.py`. |
| `frontmatter_to_ics.py` | 1.0.0 | Reads vault frontmatter (due:, scheduled:, start: fields) and writes `your-scripts.ics` calendar file. | Pipeline | Serves calendar-server via nginx bind-mount (G33). Canonical at `your-scripts/scripts/frontmatter_to_ics.py`. |
| `schedule_surface.py` | 1.0.0 | Scheduling surface pass: surfaces notes with scheduling frontmatter fields for review. | Pipeline | AUTOMATION_BACKLOG §D / §F6. Built 2026-06-13. Tag regex fixed for `#tag` format (G32). |
| `scrap_surface.py` | 1.0.0 | Scrap intake lane surface pass: surfaces scrap/fragment files for routing or triage. | Pipeline | AUTOMATION_BACKLOG scrap lane (item A). Built 2026-06-13. Symlinked at `.claudian/scripts/scrap_surface.py`. |
| `state_hook.py` | 1.0.0 | Updates handoff state after confirmed vault operations. Called by vault_agent, link_safe_move, classify, merge_files and Claudian direct ops. Updates STATE_HOOK delimited blocks only. | Utility | Built 2026-06-14. Used at every session close. Symlinked at `.claudian/scripts/state_hook.py`. |
| `rebuild_mocs.py` | 1.0.0 | Deterministic MOC rebuilder: walks vault, matches files to tag-driver mapping in REBUILD_MOCS_SPEC.md, emits extension-free [[wikilinks]] between BEGIN_GENERATED/END_GENERATED markers. CLI: `--moc <name>`, `--all`, `--apply`, `--replace-body`, `--unrouted`. Stdlib only, no LLM. | Pipeline | Built 2026-06-27 (OD-42). Symlinked at `.claudian/scripts/rebuild_mocs.py`. 9 of 11 MOCs applied 2026-06-27/28. |
| `task_surface.py` | 1.0.0 | Overload / blind-spot surface pass: surfaces overloaded tasks and scheduling blind spots for review. | Pipeline | AUTOMATION_BACKLOG §F. Built 2026-06-13. Tag regex fixed for `#tag` format (G32). Symlinked at `.claudian/scripts/task_surface.py`. |
| `task_extract.py` | 1.1.0 | Vault-wide open checkbox extraction: reads all `- [ ]` lines, deduplicates (normalized text), organizes by topic, writes review doc + append-only decision log. Read-only; never modifies sources. Blocks overwrite of review doc with tagged items. | Pipeline | Built 2026-07-01. Symlinked at `.claudian/scripts/task_extract.py`. |
| `task_promote.py` | 1.1.0 | Feedback pass for task review: reads user-coded review doc (`- [k]`, `- [j]`, `- [d]`, etc.), verifies line hash before removing from source, appends promoted items to `10_active/TO_DO.md` by category section, updates decision log. | Pipeline | Built 2026-07-01. Symlinked at `.claudian/scripts/task_promote.py`. |
| `drain.py` | 1.0.0 | Daily-note drain pipeline: extracts Tasks and Quick scraps from `20_personal/daily/<date>.md`, stages to `_handoff/DRAIN_REVIEW.md` with MANUAL_REVIEW markers; `--commit` routes approved items to `_handoff/TASKS.md` / `_handoff/SCRAPS.md`, annotates source lines, logs to `_handoff/DRAIN_LOG.txt`. Dedup key prevents re-extraction. | Pipeline | Built 2026-07-03. Symlinked at `.claudian/scripts/drain.py`. Triggered via `/drain` skill. |
| `cluster_triage.py` | 1.0.0 | D2 unreviewed agent_memory cluster triage: groups 249+ unreviewed records by difflib similarity (threshold 0.75), applies symbol-scan dismiss engine (OD/G/IH/C/DF refs, boolean closed/open lookup), emits `_handoff/UNREVIEWED_TRIAGE.md` with MANUAL_REVIEW blocks; `--commit` walks markers and updates DB status to active/dismissed. Stdlib only. | Pipeline | Built 2026-07-03. Symlinked at `.claudian/scripts/cluster_triage.py`. Spec: SPEC_D2 + SPEC_D2_delta_symbol_scan.md. |
| `token_report.py` | 1.0.0 | D5 per-session token telemetry: reads Claude Code JSONL transcripts, computes total in/out tokens, boot-phase share (turns before first non-read tool call), and tool-result bytes; appends one TSV row per session to `_handoff/TOKEN_LOG.tsv`. Exact accounting (usage fields confirmed in JSONL). Stdlib only. | Telemetry | Built 2026-07-03. Symlinked at `.claudian/scripts/token_report.py`. Run manually; SESSION_BOOT surfaces last row. |
| `inbox_mess_rewrite.py` | 1.0.0 | Dry-run manifest generator for 00_inbox + 09_mess_from_notepad cleanup. Reads each source file, sends to local Ollama (qwen3:8b primary / llama3.1 fallback) with cleanup-only rewrite rules (frontmatter/wikilinks/headings only, no content invention), aggregates proposals into `_handoff/INBOX_MESS_MANIFEST.md`. Never modifies vault files. | Pipeline | Built 2026-07-05, committed your-scripts `a6a5387`. Symlinked at `.claudian/scripts/inbox_mess_rewrite.py`. |
| `inbox_mess_apply.py` | 1.0.0 | Manifest executor: reads `_handoff/INBOX_MESS_MANIFEST.md`, applies APPROVED/EDIT entries via `link_safe_move.safe_move`. Three routing overrides: TRUE_SENSITIVE -> `20_personal/finance/` (gitignored), UTILITY_BUDGET -> `20_personal/_for_review/` (tracked), filename-incomplete -> `70_manual_review/`. backup_source copies to `.trash/<ts>__<name>.pre_rewrite` before every body write. Manifest parser masks `<details>` regions before scanning for `###` headings. | Pipeline | Built 2026-07-05, committed your-scripts `a6a5387`. Symlinked at `.claudian/scripts/inbox_mess_apply.py`. |
| `inbox_mess_diff.py` | 1.0.0 | Per-file unified diff between live sources and manifest-proposed rewritten bodies. Classifies each entry as identical / whitespace-only / frontmatter-only / minor / major. Imports `parse_manifest` from `inbox_mess_apply`: no shadow parser copy. | Pipeline | Built 2026-07-05, committed your-scripts `a6a5387`. Symlinked at `.claudian/scripts/inbox_mess_diff.py`. |

---

## .claudian/scripts/: Vault-only scripts (real files, not symlinks)

| Script | Role | Notes |
|---|---|---|
| `generate_handoff.sh` | Generates SESSION_HANDOFF_CURRENT.md | Run with `--archive` at session end |
| `gen_session_boot.sh` | Generates SESSION_BOOT.md fast-load digest | Called by generate_handoff.sh + hourly_snapshot.sh |
| `gen_vo_memory.sh` | Generates knowledge.md + projects.md from live sources | Called by generate_handoff.sh + hourly_snapshot.sh; OVERWRITE: do not hand-edit those files |
| `hourly_snapshot.sh` | Hourly vault commit + push + SESSION_BOOT + VO memory regen | Runs via crontab `0 * * * *`; vault repo only |
| `session_close.sh` | Session-end workflow wrapper | Calls generate_handoff.sh |
| `pre-sweep.sh` | Git snapshot before bulk ops | Must run before any structural sweep |
| `inventory_tree.sh` | Full system inventory: git repos, docker, ollama models, dir trees, crontab | One-off context-build for Claude. Moved from 99_system/ root 2026-06-24. |
| `parse_file.sh` | Spot-check: head/mid/tail + date scan | Decision protocol tool |
| `vault_decision_check.sh` | Pair comparison: size/diff/subset/sensitive flag | Decision protocol tool |
| `vault_tree.sh` | Vault directory tree display | Utility |
| `vault_setup.sh` | Initial vault environment setup | Setup only |
| `test_isolated_vault.sh` | Isolated vault testing | Testing harness |
| `inject_frontmatter.py` | Bulk frontmatter injection / vault audit tool | ACTIVE: restored 2026-06-26. Needed for upcoming full vault audit (updated tools + Claudian as backend agent). Phase D complete but tool retained for future audit pass. |
| `generate_tag_schema.py` | Generates TAG_SCHEMA.md from vocab.yaml | CONFIRMED ACTIVE 2026-06-26: generates the human-readable TAG_SCHEMA.md doc from vocab.yaml; classify.py D5 loading is separate (loads DOMAINS for classification, does NOT produce TAG_SCHEMA.md). Run after any vocab.yaml edit. |
| `check_links.py` | Checks vault for broken [[wiki links]] | Added 2026-06-26: moved from `.claudian/` root to `.claudian/scripts/`. 42-line utility; reports broken wikilinks to stdout. No registry entry previously. |
| `chunk_split.py` | Splits .md files into fixed-line chunks for bounded reading (global or per-file mode; --chunk-lines, --src, --out, --ext, --mode). Non-destructive: originals never modified. Writes chunks + `_MANIFEST.md`. | Added 2026-07-01 (OD-49). Extracted from `70_manual_review/mess_5.md`: the file was a Python source misfiled as `.md`. Stdlib only, 106 lines. Default `--src` hardcoded to `00_inbox/ai notes on curbing sycophancy`: override via `--src` for other targets. |
| `g4_container_test.py` | One-shot verifier for G-4 gate (see VO_CLASSIFY_PIPELINE_BROKEN.md). Exercises `vault_agent._resolve_tag_destination` and `link_safe_move.validate_destination_schema` as pure function calls. No file moves. Writes manifest to `_handoff/g4_test_manifest_<ts>.md`. | Added 2026-07-05. Runs inside pas-agent-runner: `docker exec pas-agent-runner python3 /vault/.claudian/scripts/g4_container_test.py`. Archive-candidate once G-4 is marked DONE in VO_CLASSIFY_PIPELINE_BROKEN.md. |
| `g54_override_test.py` | One-shot verifier for GOTCHAS G54. Exercises TRUE_SENSITIVE + FINANCE_DOWNGRADE override paths in `inbox_mess_apply.override_destination` through a real `safe_move` (with cleanup). Writes manifest to `_handoff/g54_test_manifest_<ts>.md`. | Added 2026-07-05. Runs on host (NOT in container: inbox_mess_apply.py is not part of the pas-agent-runner call surface per G-3b). Requires pas-agent-runner STOPPED for isolation. Archive-candidate once G54 is closed. |
| `intake_gate.py` | Deterministic intake checkpoint (no LLM): frontmatter present, no `.md`-extension wikilinks, no secret patterns (canonical set -> SYSTEM_CONSTANTS.md), filename hygiene, non-empty body. `--inbox` scans `00_inbox/*.{md,txt}`. Exit 0 PASS / 1 FAIL; JSON per file. | Written prior session; wired + hardened 2026-07-23. Secret set unified to the pre-commit hook 2026-07-23 (was weaker: PASSed a `token:<uuid>` leak). Trigger integration (agent_runner/classify + n8n inbox-watch) tracked in PENDING_WORK. |
| `api_catalog_build.py` | Deterministic public-apis README parser -> `99_system/API_CATALOG.md` (51 categories / 1,585 APIs with Auth/HTTPS/CORS). Dry-run default; `--apply` writes; `--src` for offline. Preamble above BEGIN_GENERATED preserved (rebuild_mocs contract). Stdlib only, no LLM. | Added 2026-07-23. Consumed by `/api-lookup` skill. Re-run `--apply` on staleness. |
| `intake_gate.js` | Node twin of `intake_gate.py`: same checks, for the n8n/JS substrate. Verdict parity by construction; MUST stay in sync with the `.py` copy and the SYSTEM_CONSTANTS.md secret set. | Added 2026-07-23. JS-runtime parity check pending a node-capable env (node absent in sandbox 2026-07-23). |
| `archive/` | Migration scripts (2026-06-04), older pipelines | Review: confirm nothing active lives here |

---

## Consolidation candidates

### 1. Utility module grouping
Five scripts (`op_log`, `op_idempotency`, `validate_frontmatter`, `interaction_log`, `time_context`) are pure utilities. **Current separation is readable and intentional**: each has a single well-defined purpose. Do not merge into a monolithic utils.py.
- **Decision:** Keep separate. Add a `README.md` or module docstring cross-reference.

### 3. `dedup_pipeline.py` vs `merge_files.py`: confusing split
- `dedup_pipeline.py` = exact hash dedup (czkawka, all file types)
- `merge_files.py` = semantic text dedup (.md/.txt only, chunk/intake use)
- These are deliberately different mechanisms. Not merge candidates.
- **Action needed:** Add a comment at top of both explaining the split and when each runs.

### 4. `.claudian/scripts/inject_frontmatter.py`: KEPT ACTIVE 2026-06-26
- Phase D complete, but retained for upcoming full vault audit (Claudian backend + updated tools pipeline).
- **Resolution:** Restored from archive/ same session. Not archivable until vault audit pass is complete.

### 5. `.claudian/scripts/generate_tag_schema.py`: CLOSED 2026-06-26
- ~~Generates TAG_SCHEMA.md from vocab. vocab.yaml now exists (D5).~~
- **Resolution:** CONFIRMED ACTIVE. classify.py D5 loading reads vocab.yaml for DOMAINS (runtime classification); generate_tag_schema.py generates the human-readable TAG_SCHEMA.md doc (documentation artifact). Different roles, not redundant. Keep as-is.

### 6. `archive/` contents in `.claudian/scripts/archive/`
- Contains: migration_20260604/ scripts, zipd/ scripts, older vault_pipeline.py etc. + inject_frontmatter.py (added 2026-06-26).
- These are historical. Confirm nothing is symlinked to them, then assess if they should be deleted or kept as reference.

---

## Architecture diagram (3-layer)

```
Transport      agent_runner.py          (HTTP server, n8n bridge)
               v
Orchestration  vault_agent.py          (LLM loop, tool dispatch)
               v
Primitives     link_safe_move.py        (move)
               classify.py             (classify)
               chroma_reconcile.py     (index sync)
               dedup_pipeline.py       (hash dedup)
               merge_files.py          (text dedup, intake only)
               v
Utilities      op_log / op_idempotency / validate_frontmatter
               interaction_log / time_context
```

---

## Review tasks

- [x] Confirm `inject_frontmatter.py` is archivable: CLOSED 2026-06-26. Decision: KEPT ACTIVE at `.claudian/scripts/inject_frontmatter.py` (restored same day; file is at vault scripts root, not in archive).
- [x] Confirm `generate_tag_schema.py` role vs vocab.yaml: CLOSED 2026-06-26. Confirmed active; different role from D5 classify.py loading.
- [x] Symlinks accurate post-review: CLOSED 2026-06-26 (T12 audit; C3 VALIDATE: OK, 26 symlinks clean).
- [ ] Audit `archive/` contents: DEFERRED (historical scripts, not urgent; inject_frontmatter.py now added there too)
- [ ] Add cross-reference comments to dedup_pipeline.py + merge_files.py: still open

---

*Created: 2026-06-11 | Claudian*
