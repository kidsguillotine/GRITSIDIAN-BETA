# crm

Person notes (contacts). Optional; remove if unused.

See `99_system/FOLDER_SCHEMA.md` for the full taxonomy.
